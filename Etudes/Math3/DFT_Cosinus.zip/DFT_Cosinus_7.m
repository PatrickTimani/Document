% DFT_Cosinus_7.m
%
% DFT eines Cosinus

% 25.11.2012 Stefan Hillenbrand
clear, close all

%% Definition der Funktion und der Abtastung
f = 1;
dT = 1/8;
N = 20;
t = 0:dT:(N-1)*dT;
tf = 0:.01:max(t);

% Definition der Funktion
x = cos(2*pi*f*t);
xf = cos(2*pi*f*tf);

% Hanning Fenster
h = 0.5*(1-cos(2*pi*t/dT/(N-1)));
hf = 0.5*(1-cos(2*pi*tf/(max(t))));

% Anwenden des Fensters
x = x.*h;

%% Zeichnen
figure
plot(tf, xf, tf, hf, tf, xf.*hf)
hold on
stem(t,x, 'r');
hold off
xlabel('Zeit [s]')
ylabel('x(t), x(k\Delta T)')
legend('Signal', 'Hanning-Fenster', 'gefenstertes Signal', 'Location', 'SouthWest')

%% Zero-Padding: erweitern auf 100 Werte
N2 = 100;
x = [x zeros(1,N2-N)];
% Neuer Zeitvektor f�r die Abtastung
t = [t N*dT+(0:N2-N-1)*dT];

figure
plot(tf, xf.*hf);
hold on
stem(t,x, 'r');
hold off
xlabel('Zeit [s]')
ylabel('x(t), x(k\Delta T)')

%% Fourier-Transformation
X = fft(x);
om0=2*pi/N2/dT;
om = 0:om0:(N2-1)*om0;

figure
stem(om, abs(X), 'r')
xlabel('\omega [rad/s]')
ylabel('|X|')