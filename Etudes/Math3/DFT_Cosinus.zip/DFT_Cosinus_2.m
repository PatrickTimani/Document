% DFT_Cosinus_2.m
%
% DFT eines Cosinus

% 25.11.2012 Stefan Hillenbrand
clear, close all

%% Definition der Funktion und der Abtastung
f = 1;
dT = 1/8;
N = 17;
t = 0:dT:(N-1)*dT;
tf = 0:.01:max(t);
x = cos(2*pi*f*t);
xf = cos(2*pi*f*tf);

%% Zeichnen
figure
plot(tf, xf);
hold on
stem(t,x, 'r');
hold off
xlabel('Zeit [s]')
ylabel('x(t), x(k\Delta T)')

%% Fourier-Transformation
X = fft(x);
om0=2*pi/N/dT;
om = 0:om0:(N-1)*om0;

figure
subplot(2,1,1)
stem(om, real(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Real(X)')
subplot(2,1,2)
stem(om, imag(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Imag(X)')
ylim([-5 10])

%% Zeichnen des Betragsspektrums
figure
stem(om, abs(X), 'r')
xlabel('\omega [rad/s]')
ylabel('|(X)|')

%% Periodische Fortsetzung des Ursprungsignals
tf2=[tf tf+N*dT];
xf2 = [xf xf];
t2 = [t t+N*dT];
x2 = [x x];

figure
plot(tf2, xf2);
hold on
stem(t2,x2, 'r');
hold off
xlabel('Zeit [s]')
ylabel('x(t), x(k\Delta T)')
title('Periodische Fortsetzung des Zeitsignals')