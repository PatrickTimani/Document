% DFT_Cosinus_1.m
%
% DFT eines Cosinus

% 25.11.2012 Stefan Hillenbrand
clear, close all

%% Definition der Funktion und der Abtastung
f = 1;
dT = 1/8;
N = 16;
t = 0:dT:(N-1)*dT;
tf = 0:.01:max(t);
x = cos(2*pi*f*t);
xf = cos(2*pi*f*tf);

%% Zeichnen der Funktion
figure
plot(tf, xf);
hold on
stem(t,x, 'r');
hold off
xlabel('Zeit [s]')
ylabel('x(t), x(k\Delta T)')


%% Fourier-Transformation
X = fft(x);
om0=2*pi/N/dT;
om = 0:om0:(N-1)*om0;

figure
subplot(2,1,1)
stem(om, real(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Real(X)')
subplot(2,1,2)
stem(om, imag(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Imag(X)')
ylim([-5 10])

%% Periodische Fortsetzung des Spektrums
om2=om-N*om0;
figure
subplot(2,1,1)
stem(om, real(X),'r')
hold on
stem(om2, real(X),'b')
hold off
xlabel('\omega [rad/s]')
ylabel('Real(X)')
subplot(2,1,2)
stem(om, imag(X),'r')
hold on
stem(om2, imag(X),'b')
hold off
xlabel('\omega [rad/s]')
ylabel('Imag(X)')
ylim([-5 10])

%% Darstellung mit FFTSHIFT
om3=-N/2*om0:om0:(N/2-1)*om0;

figure
subplot(2,1,1)
X = fftshift(X);
stem(om3, real(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Real(X)')
subplot(2,1,2)
stem(om3, imag(X), 'r')
xlabel('\omega [rad/s]')
ylabel('Imag(X)')
ylim([-5 10])

