/**
 * 
 */
package de.hspforzheim.eit.studies;

import java.util.Iterator;
import java.util.Observable;
import java.util.Vector;

/**
 * @author martin.pfeiffer
 * 
 */
public class Lecture extends Observable {
	private Vector<String> contents;
	private String title;
	private int nextLecture;

	public Lecture() {
		contents = new Vector<String>();
		nextLecture = 0;
	}

	public Lecture(String t) {
		this();
		title = t;
	}

	public Lecture(int cnt, String t) {
		this(t);
		contents.setSize(cnt);
	}

	public void addChapter(int num, String theme) {
		while (num >= contents.size()) {
			contents.add("N.N.");
		}
		contents.set(num, theme);
	}

	public String overview() {
		String res = "";
		Iterator<String> it = contents.iterator();
		int i = 1;
		while (it.hasNext()) {
			res += i + ". ";
			res += it.next();
			res += "\n";
			i++;
		}
		return res;
	}

	synchronized public void holdLecture(Professor p) {
		String res = "";
		if (nextLecture >= contents.size()) {
			;
		} else {
			res = createLecture(nextLecture, p.getName());
			nextLecture++;
			setChanged();
		}
		notifyObservers(res);
	}

	synchronized public boolean isFinished() {
		boolean res;
		if (nextLecture >= contents.size()) {
			res = true;
		} else {
			res = false;
		}
		return res;
	}

	synchronized public void nextTerm() {
		nextLecture = 0;
	}

	private String createLecture(int i, String prof) {
		return "Guten Tag, ich begr��e Sie zur " + (i + 1)
				+ ". Vorlesung zum Thema " + title + ".\nMein Name ist " + prof
				+ ".\nUnser heutiges Thema ist " + contents.get(i) + ".\n";

	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
}
