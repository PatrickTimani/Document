/**
 * 
 */
package de.hspforzheim.eit.studies;

import java.util.Vector;

/**
 * @author martin.pfeiffer
 * 
 */
public class ActiveProf extends Professor implements Runnable {
	private Vector<Lecture> myLectures;

	/**
	 * @param n
	 */
	public ActiveProf(String n) {
		super(n);
		myLectures = new Vector<Lecture>();
		// TODO Auto-generated constructor stub
	}

	public void addLecture(Lecture l) {
		myLectures.add(l);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean termIsOver = false;
		for (int i = 0; i < 10; i++) {
			while (!termIsOver) {
				termIsOver = true;
				for (Lecture l : myLectures) {
					doLecture(l);
					termIsOver &= !l.isFinished();
				}
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (Lecture l : myLectures) {
				l.nextTerm();
			}
			termIsOver = false;
		}

	}

}
