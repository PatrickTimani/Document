/**
 * 
 */
package de.hspforzheim.eit.studies;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

/**
 * @author martin.pfeiffer
 * 
 */
public class Student implements Observer {

	private String name = "";
	private HashMap<Lecture, String> scripts;

	public Student(String n) {
		name = n;
		scripts = new HashMap<Lecture, String>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.Observer#update(java.util.Observable, java.lang.Object)
	 */
	@Override
	public void update(Observable lect, Object lecText) {
		/**
		 * If we modify the script we need to take care: some other thread may
		 * also do so. So we synchronize ourselves w.r.t. scripts.
		 */
		synchronized (scripts) {
			String actScript = scripts.get(lect);
			actScript += "\n" + lecText;
			scripts.put((Lecture) lect, actScript);
		}
	}

	public void registerLecture(Lecture l) {
		l.addObserver(this);
		synchronized (scripts) {
			scripts.put(l, "");
		}
	}

	private void save0(String lecName, String text) {
		try {
			FileWriter fw;
			fw = new FileWriter("C:\\temp\\" + name + "_" + lecName + ".txt");
			fw.write(text);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void saveAll() {
		/**
		 * Synchronized to be sure that nobody modifieds the scripts while we
		 * are outputting.
		 */
		synchronized (scripts) {
			for (Lecture l : scripts.keySet()) {
				save0(l.getTitle(), scripts.get(l));
			}
		}
	}

}
