/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 *
 */
public class LectureTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//test01();
		test02();
		
		
	}
	

	static private void test01(){
		Lecture l1 = new Lecture("Mobilkommunikation");
		l1.addChapter(0, "Einf�hrung");
		l1.addChapter(3, "TCP/IP");
		l1.addChapter(2, "Signale");
		l1.addChapter(5, "UMTS");

		Lecture l2 = new Lecture("Serielle Bussysteme");
		l2.addChapter(0, "Einf�hrung");
		l2.addChapter(3, "LIN");
		l2.addChapter(2, "CAN");
		l2.addChapter(6, "FlexRay");
		l2.addChapter(4, "OSEK NM");
		l2.addChapter(5, "Diagnoseprotokolle");

		System.out.println(l2.overview());
		
		Student s1 = new Student("Karl");
		Student s2 = new Student("Fritz");
		Student s3 = new Student("Eugen");
		
		s1.registerLecture(l1);
		s1.registerLecture(l2);
		s2.registerLecture(l1);
		s3.registerLecture(l2);
		
		Professor p1 = new Professor("Pfeiffer");
		Professor p2 = new Professor("Niemann");
		
		p2.doLecture(l1);
		p1.doLecture(l2);
		p2.doLecture(l2);
		p2.doLecture(l1);
		p1.doLecture(l2);
		p1.doLecture(l2);
		p1.doLecture(l2);
		p1.doLecture(l2);
		p2.doLecture(l1);
		p1.doLecture(l2);
		p1.doLecture(l2);
		
		s1.saveAll();
		s2.saveAll();
		s3.saveAll();	
	}


	static private void test02(){
		Lecture l1 = new Lecture("Mobilkommunikation");
		l1.addChapter(0, "Einf�hrung");
		l1.addChapter(3, "TCP/IP");
		l1.addChapter(2, "Signale");
		l1.addChapter(5, "UMTS");

		Lecture l2 = new Lecture("Serielle Bussysteme");
		l2.addChapter(0, "Einf�hrung");
		l2.addChapter(3, "LIN");
		l2.addChapter(2, "CAN");
		l2.addChapter(6, "FlexRay");
		l2.addChapter(4, "OSEK NM");
		l2.addChapter(5, "Diagnoseprotokolle");

		System.out.println(l2.overview());
		
		Student s1 = new Student("Karl");
		Student s2 = new Student("Fritz");
		Student s3 = new Student("Eugen");
		
		s1.registerLecture(l1);
		s1.registerLecture(l2);
		s2.registerLecture(l1);
		s3.registerLecture(l2);
		
		ActiveProf p1 = new ActiveProf("Pfeiffer");
		ActiveProf p2 = new ActiveProf("Niemann");

		p1.addLecture(l1);
		p2.addLecture(l1);
		p1.addLecture(l2);
		p2.addLecture(l2);
		
		Thread t1 = new Thread(p1);
		Thread t2 = new Thread(p2);
		
		t1.start();
		t2.start();
		
		while(t2.isAlive()){
			t2.interrupt();
		}
		while(t1.isAlive());
		
		s1.saveAll();
		s2.saveAll();
		s3.saveAll();
	}

}
