import java.lang.reflect.Method;


import de.hspforzheim.eit.helpers.Keyin;

/**
 * Program to calculate Fibonacci numbers.
 * Illustration for recursion and iteration.
 */

/**
 * @author martin.pfeiffer
 * 
 */
public class Fibo {

	/**
	 * Read in the number for which to calculate the fib.
	 * Also prompt the user for the method to be used.
	 */
	public static void main(String[] args) {
		long num = (long) Keyin.inInt("Zahl >");
		String met = Keyin.inString("Methode (Rek, Iter) >");
		Method m;
		try {
			m = Fibo.class.getMethod("fibo" + met, long.class);
			long res = (Long) m.invoke(Fibo.class, (long) num);
			System.out.println("fib(" + num + ") = " + res);
		} catch (Exception e) {
			System.out.println("'" + met + "' is not a valid method.");
			return;
		}
	}

	/**
	 * Recursive calculation of fibonacci numbers.
	 * 
	 * @param f
	 *            Number for which fib is to be calculated.
	 * 
	 * @return fib(f)
	 */
	public static long fiboRek(long f) {
		long res;
		if (f < 2) {
			// For little numbers we know.
			res = 1L;
		} else {
			// Here comes the recursion.
			res = Fibo.fiboRek(f - 1) + Fibo.fiboRek(f - 2);
		}
		return res;
	}

	/**
	 * Iterative calculation of fibonacci numbers.
	 * 
	 * @param f
	 *            Number for which fib is to be calculated.
	 * 
	 * @return fib(f)
	 */
	public static long fiboIter(long val) {
		// Use an array to store the latest numbers
		long arr[] = { 1L, 1L, 2L };
		long res;
		if (val < 3) {
			// For little numbers we know...
			res = arr[(int) val];
		} else {
			// And now we step through the numbers.
			for (int i = 3; i <= val; i++) {
				arr[i % 3] = arr[(i - 1) % 3] + arr[(i - 2) % 3];
			}
			res = arr[(int) (val % 3)];
		}
		return res;
	}

}
