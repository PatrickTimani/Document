package de.hspforzheim.eit.helpers;

/**
 * Helper class to read in data from console.
 * 
 * @author martin.pfeiffer
 * @version 1.0
 * 
 */
public class Keyin {

	/**
	 * Method to display the user's prompt string
	 * 
	 * @param prompt
	 *            Text used as a prompt.
	 */
	private static void printPrompt(String prompt) {
		System.out.print(prompt + " ");
		System.out.flush();
	}

	/**
	 * Method to make sure no data is available in the input stream.
	 */
	private static void inputFlush() {

		try {
			while ((System.in.available()) != 0)
				System.in.read();
		} catch (java.io.IOException e) {
			System.out.println("Input error");
		}
	}

	/**
	 * Read in a String from console with prompt
	 * 
	 * @param prompt
	 *            Text used as a prompt.
	 */
	public static String inString(String prompt) {
		inputFlush();
		printPrompt(prompt);
		return inString0();
	}

	/**
	 * Read in a String Internal method
	 */
	private static String inString0() {
		int aChar;
		String s = "";
		boolean finished = false;

		while (!finished) {
			try {
				aChar = System.in.read();
				if (aChar < 0 || (char) aChar == '\n')
					finished = true;
				else if ((char) aChar != '\r')
					s = s + (char) aChar; // Enter into string
			}

			catch (java.io.IOException e) {
				System.out.println("Input error");
				finished = true;
			}
		}
		return s;
	}

	/**
	 * Read in an integer number from console with prompt
	 * 
	 * @param prompt
	 *            Text used as a prompt.
	 */
	public static int inInt(String prompt) {
		while (true) {
			inputFlush();
			printPrompt(prompt);
			try {
				return Integer.valueOf(inString0().trim()).intValue();
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Not an integer");
			}
		}
	}

	/**
	 * Read in a character from console with prompt
	 * 
	 * @param prompt
	 *            Text used as a prompt.
	 */
	public static char inChar(String prompt) {
		int aChar = 0;

		inputFlush();
		printPrompt(prompt);

		try {
			aChar = System.in.read();
		} catch (java.io.IOException e) {
			System.out.println("Input error");
		}
		inputFlush();
		return (char) aChar;
	}

	/**
	 * Read in a double number from console with prompt
	 * 
	 * @param prompt
	 *            Text used as a prompt.
	 */
	public static double inDouble(String prompt) {
		while (true) {
			inputFlush();
			printPrompt(prompt);
			try {
				return Double.valueOf(inString0().trim()).doubleValue();
			}

			catch (NumberFormatException e) {
				System.out
						.println("Invalid input. Not a floating point number");
			}
		}
	}
}
