/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class ReviewTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PostBox<Report> pb = new PostBox<Report>(2);
		WaitSet<String, Report> sec = new WaitSet<String, Report>();

		for (int i = 0; i < 20; i++) {
			Student s = new Student("Student #" + i, pb, sec);
			new Thread(s).start();
		}
		Reviewer c1 = new Reviewer("Bauer", pb, sec);
		Reviewer c2 = new Reviewer("Pfeiffer", pb, sec);
		Thread t;
		t = new Thread(c1);
		t.setDaemon(true);
		t.start();

		t = new Thread(c2);
		t.setDaemon(true);
		t.start();

	}

}
