/**
 * A Reviwer reviews reports and marks them as reviewed.
 * A Reviewer receives reports via an inbox (PostBox) and returns the reviewed reports in an outbox (WaitSet).
 * 
 * @see PostBox, WaitSet, Report
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class Reviewer extends Person implements Runnable {
	private PostBox<Report> myInBox;
	private WaitSet<String, Report> myOutBox;

	public Reviewer(String n, PostBox<Report> pb, WaitSet<String, Report> ws) {
		super(n);
		myInBox = pb;
		myOutBox = ws;
	}

	@Override
	public void run() {
		try {
			/**
			 * Never ending story... So we need to do this in a demon thread
			 */
			while (true) {
				/**
				 * Take one report out of the box
				 */
				Report currRep = myInBox.readItem();
				/**
				 * Review takes some time :-)
				 */
				Thread.sleep((long) (200 * Math.random()));
				/**
				 * Now sign the report...
				 */
				currRep.reviewReport(getName());
				/**
				 * ...and put in into the return box.
				 */
				currRep.returnReport(myOutBox);
			}
		} catch (InterruptedException e) {
			;
		}

	}

}
