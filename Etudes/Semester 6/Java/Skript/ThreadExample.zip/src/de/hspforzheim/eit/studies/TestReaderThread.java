/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class TestReaderThread implements Runnable {
	private PostBox<String> myInBox;
	private int num;

	/**
	 * 
	 */
	public TestReaderThread(PostBox<String> pb, int n) {
		myInBox = pb;
		num = n;
	}

	@Override
	public void run() {
		for (int i = 0; i < num; i++) {
			String buf = "";
			buf = myInBox.readItem();
			System.out.println("Just read: " + buf);
			try {
				Thread.sleep((long) (100 * Math.random()));
			} catch (InterruptedException e) {
				System.out.println("Lesen schiefgelaufen");
			}
		}

	}

}
