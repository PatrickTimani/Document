/**
 * State model for reports
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public enum ReportState {
	NEW, // newly created
	WRITTEN, // report written
	IN_REVIEW, // delivered to reviewer
	REVIEWED, // reviewed by reviewer
	FINISHED; // returned to sender...
}
