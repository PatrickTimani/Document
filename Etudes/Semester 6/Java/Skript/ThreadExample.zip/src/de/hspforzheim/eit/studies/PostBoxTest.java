/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class PostBoxTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PostBox<String> pb = new PostBox<String>(5);
		int n=100;
		TestWriterThread tw = new TestWriterThread(pb, n);
		TestReaderThread tr = new TestReaderThread(pb, n);
		new Thread(tr).start();
		new Thread(tw).start();
	}

}
