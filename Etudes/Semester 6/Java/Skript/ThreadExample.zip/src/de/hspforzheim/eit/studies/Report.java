/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class Report {
	static final String nl = System.getProperty("line.separator");
	private String contents = "";
	private ReportState state = ReportState.NEW;
	private String author = "";
	private String reviewer = "";

	public void addContents(String s) {
		contents += s + nl;
		if (state == ReportState.NEW)
			state = ReportState.WRITTEN;
	}

	public String reportAll() {
		String res = "";
		res += "Author: " + author + nl;
		res += "Reviewer: " + reviewer + nl;
		res += "State: " + state + nl;
		res += contents;
		return res;

	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(ReportState state) {
		this.state = state;
	}

	/**
	 * @param author
	 *            the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	public void deliverReport(PostBox<Report> pb) {
		if (state != ReportState.WRITTEN) {
			return;
		}
		state = ReportState.IN_REVIEW;
		pb.addItem(this);
	}

	public void reviewReport(String n) {
		if (state != ReportState.IN_REVIEW) {
			return;
		}
		state = ReportState.REVIEWED;
		reviewer = n;
	}

	public void returnReport(WaitSet<String, Report> box) {
		box.addItem(author, this);
	}

}
