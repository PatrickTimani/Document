/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class Person {
	private String name = "";

	public Person(String n) {
		name = n;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

}
