/**
 * 
 */
package de.hspforzheim.eit.studies;

import java.util.HashMap;

/**
 * @author martin.pfeiffer
 * 
 */
public class WaitSet<K, V> {
	/**
	 * Container for the elements to store.
	 */
	private HashMap<K, V> myItems;

	public WaitSet() {
		myItems = new HashMap<K, V>();
	}

	synchronized public void addItem(K key, V item) {
		if (myItems.containsKey(key)) {
			/**
			 * Item already in Elements
			 */
			;
		} else {
			myItems.put(key, item);
			/**
			 * Someone might be waiting. Now we have to notify all because the
			 * first to be activated might not be the right one.
			 */
			notifyAll();
		}
	}
	
	synchronized public V getItem(K key) {
		V res = null;
		while (!myItems.containsKey(key)) {
			/**
			 * Item is not available. So we wait.
			 */
			try {
				wait();

			} catch (InterruptedException e) {
				/**
				 * No need to do something here. If we do not get our item we
				 * are back in a second...
				 */
				;
			}
		}
		res = myItems.remove(key);
		return res;
	}

}
