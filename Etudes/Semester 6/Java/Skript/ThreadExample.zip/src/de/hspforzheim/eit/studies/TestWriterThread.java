/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class TestWriterThread implements Runnable {

	private PostBox<String> myOutBox;
	private int num;

	/**
	 * 
	 */
	public TestWriterThread(PostBox<String> box, int n) {
		myOutBox = box;
		num = n;
	}

	@Override
	public void run() {
		for (int i = 0; i < num; i++) {
			myOutBox.addItem("String #" + i);
			System.out.println("Wrote #" + i);
			try {
				Thread.sleep((long) (10 * Math.random()));
			} catch (InterruptedException e) {
				System.out.println("Schreiben schiefgelaufen");
			}
		}

	}

}
