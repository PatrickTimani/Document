/**
 * PostBox is a generic implementation of a message queue making use of a ring buffer.
 */
package de.hspforzheim.eit.studies;

import java.util.Vector;

/**
 * @author martin.pfeiffer
 * 
 *         PostBox objects represent and message queue with a certain capacity
 * 
 */
public class PostBox<T> {
	private Vector<T> queue;
	private int readIdx;
	private int writeIdx;

	public PostBox(int capacity) {
		/**
		 * First we check if the capacity is at least 2. If not we set it to 2.
		 * This is not very safe code! We implicitly change some property
		 * without giving feedback to the user!
		 */
		if (capacity < 2)
			capacity = 2;
		queue = new Vector<T>();
		queue.setSize(capacity);
		/**
		 * Initialize the read and write position. The write idx marks the
		 * element that will be written next. The read idx marks the element
		 * that will be read next. Both indices must never overtake each other.
		 */
		readIdx = 0;
		writeIdx = 0;

	}

	public synchronized void addItem(T item) {
		while (!canWrite()) {
			/**
			 * The queue is full. We need to wait until someone tells us to wake
			 * up. We then still have to check if the write access is available
			 * because some other thread might have come in between.
			 */
			try {
				wait();
			} catch (InterruptedException e) {
				/**
				 * Do nothing if interrupted
				 */
				;
			}
		}

		/**
		 * Now we have access to the queue and it is not full. So we write.
		 */
		queue.set(writeIdx, item);
		/**
		 * We notify that the queue has something to read in. If we wouldn't do
		 * other threads would wait endlessly.
		 */
		notify();
		writeIdx = (writeIdx + 1) % (queue.size());
	}

	public synchronized T readItem() {
		T result = null;
		while (!canRead()) {
			/**
			 * The queue is empty. We need to wait until some tells other to
			 * wake up. We then still have to check if the read access is
			 * available because some other thread might have come in between.
			 */
			try {
				wait();
			} catch (InterruptedException e) {
				/**
				 * Do nothing if interrupted
				 */
				;
			}
		}

		/**
		 * Now we have access to the queue and it is not empty. So we take the
		 * next item.
		 */
		result = queue.get(readIdx);
		/**
		 * We notify that the queue has space to write in again. If we wouldn't
		 * do other threads would wait endlessly.
		 */
		notify();
		readIdx = (readIdx + 1) % (queue.size());

		return result;
	}

	/**
	 * This method checks if the queue has elements to be read. It must be
	 * called from a synchronized method.
	 * 
	 * @return true if the current thread can read, false if not.
	 */
	private boolean canRead() {
		boolean res;
		if (readIdx == writeIdx) {
			/**
			 * In this case the read idx would overtake the write idx. So we are
			 * not allowed to read.
			 */
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	/**
	 * This method checks if an item can be added to the queue. It must be
	 * called from a synchronized method.
	 * 
	 * @return true if an item can be added, false if not.
	 */
	private boolean canWrite() {
		boolean res;
		int nextPos;
		/**
		 * Virtually go to the next read position.
		 */
		nextPos = (writeIdx + 1) % (queue.size());
		if (nextPos == readIdx) {
			/**
			 * In this case the write idx would overtake the read idx. So we are
			 * not allowed to write.
			 */
			res = false;
		} else {
			res = true;
		}
		return res;
	}

}
