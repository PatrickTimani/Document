/**
 * 
 */
package de.hspforzheim.eit.studies;

/**
 * @author martin.pfeiffer
 * 
 */
public class Student extends Person implements Runnable {

	private PostBox<Report> outBox;
	private WaitSet<String, Report> returnBox;

	/**
	 * @param n
	 */
	public Student(String n, PostBox<Report> pb, WaitSet<String, Report> sec) {
		super(n);
		outBox = pb;
		returnBox = sec;
	}

	@Override
	public void run() {
		/**
		 * Take some random number of working days.
		 */
		int workingDays = (int) (100 + 20 * Math.random());

		/**
		 * Create a report...
		 */
		Report rep = new Report();
		/**
		 * ...and add the author
		 */
		rep.setAuthor(this.getName());

		try {
			for (int i = 0; i < workingDays; i++) {
				Thread.sleep((long) (10 * Math.random()));
			}

			rep.addContents("# of days: " + workingDays);

			/**
			 * Time for a first report. As another thread might also output we
			 * need to synchronize with the System object.
			 */
			synchronized (System.class) {
				System.out.println(rep.reportAll());
			}

			rep.deliverReport(outBox);
			
			/**
			 * Again synchronize...
			 */
			synchronized (System.class) {
				System.out.println(rep.reportAll());
			}

			/**
			 * Forget about the report...
			 */
			rep = null;

			Thread.sleep((long) (1000 * Math.random()));

			rep = returnBox.getItem(getName());
			
			/**
			 * Final report...
			 */
			rep.setState(ReportState.FINISHED);
			synchronized (System.class) {
				System.out.println(rep.reportAll());
			}
		} catch (InterruptedException e) {
			;
		}

	}

}
