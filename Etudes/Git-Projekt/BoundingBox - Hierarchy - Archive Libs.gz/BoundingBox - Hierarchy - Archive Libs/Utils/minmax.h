#ifndef minmax_h
#define minmax_h

#define MIN2(a,b)  (a) < (b) ? (a) : (b)
#define MIN3(a,b,c) MIN2(MIN2((a),(b)), (c))
#define MIN4(a,b,c,d) MIN2(MIN3((a),(b),(c)), (d))

#define MAX2(a,b) (a) > (b) ? (a) : (b)
#define MAX3(a,b,c) MAX2(MAX2((a),(b)), (c))
#define MAX4(a,b,c,d) MAX2(MAX3((a),(b),(c)),(d))


#endif
