#ifndef Kreis_h
#define Kreis_h

#define PI 3.14159265

#include "Punkt.h"

/************ Kreis *************/
struct sKreis
{
	/*		     ---				*/
	/*		   / r   \		r = radius  	*/
	/*		  |   . m |				*/
	/*		   \     /				*/
	/*	             ---				*/
	PUNKT m;
	double radius;
} ;

typedef struct sKreis KREIS;

void Kreis_definiere(PUNKT x, double dRadius, KREIS* meinKreis);
double Kreis_Flaeche(KREIS* meinKreis);
double Kreis_Umfang(KREIS* meinKreis);
double Kreis_Bogen(double alpha, KREIS* meinKreis);
double Kreis_Sektor(double alpha, KREIS* meinKreis);

double Kreis_xmin(KREIS* meinKreis);
double Kreis_xmax(KREIS* meinKreis);
double Kreis_ymin(KREIS* meinKreis);
double Kreis_ymax(KREIS* meinKreis);

#endif
