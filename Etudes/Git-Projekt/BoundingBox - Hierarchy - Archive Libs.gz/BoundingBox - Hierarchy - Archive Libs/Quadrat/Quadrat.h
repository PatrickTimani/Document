#ifndef Quadrat_h
#define Quadrat_h

#include "Punkt.h"
#include "Strecke.h"


/************ Quadrat *************/

struct sQuadrat
{

	/*		D-----------C		*/
	/*		|  	    |		*/
	/*		|  	    |		*/
	/*	  	| 	    |a		*/
	/*		| 	    |		*/
	/*		|  	    |		*/
	/*		A-----------B		*/
	/*		      a			*/

	PUNKT A,B,C,D;

} ;

typedef struct sQuadrat QUADRAT;

void Quadrat_definiere(PUNKT w, PUNKT x, PUNKT y, PUNKT z, QUADRAT* meinQuadrat);
double Quadrat_Flaeche(QUADRAT* meinQuadrat);
double Quadrat_Umfang(QUADRAT* meinQuadrat);
double Quadrat_xmin(QUADRAT* meinQuadrat);
double Quadrat_xmax(QUADRAT* meinQuadrat);
double Quadrat_ymin(QUADRAT* meinQuadrat);
double Quadrat_ymax(QUADRAT* meinQuadrat);

#endif
