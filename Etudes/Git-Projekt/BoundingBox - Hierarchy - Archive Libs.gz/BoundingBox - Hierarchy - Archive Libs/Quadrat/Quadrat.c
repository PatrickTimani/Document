#include "Quadrat.h"
#include "Strecke.h"
#include <math.h>
#include "minmax.h"

/************ Quadrat *************/
void Quadrat_definiere(PUNKT w, PUNKT x, PUNKT y, PUNKT z, /*@out@*/ QUADRAT* meinQuadrat)
{	
	/*		z-------y		*/
	/*		|  		|		*/
	/*	  	| 		|a		*/
	/*		| 		|		*/
	/*		w-------x		*/
    /*			a			*/

	meinQuadrat->A=w;
	meinQuadrat->B=x;
	meinQuadrat->C=y;
	meinQuadrat->D=z;
	
}


double Quadrat_Flaeche(QUADRAT* meinQuadrat)
{
	STRECKE a;
	Strecke_definiere(meinQuadrat->A, meinQuadrat->B,&a);

	return Strecke_laenge(a)*Strecke_laenge(a);
}

double Quadrat_Umfang(QUADRAT* meinQuadrat)
{
	STRECKE a;
	Strecke_definiere(meinQuadrat->A, meinQuadrat->B,&a);

	return 4 * (Strecke_laenge(a));
}

double Quadrat_xmin(QUADRAT* meinQuadrat)
{
	return MIN4(Punkt_x(meinQuadrat->A),Punkt_x(meinQuadrat->B),Punkt_x(meinQuadrat->C), Punkt_x(meinQuadrat->D));
}

double Quadrat_xmax(QUADRAT* meinQuadrat)
{
	return MAX4(Punkt_x(meinQuadrat->A),Punkt_x(meinQuadrat->B),Punkt_x(meinQuadrat->C), Punkt_x(meinQuadrat->D));
}

double Quadrat_ymin(QUADRAT* meinQuadrat)
{ 
	return MIN4(Punkt_y(meinQuadrat->A),Punkt_y(meinQuadrat->B),Punkt_y(meinQuadrat->C), Punkt_x(meinQuadrat->D));

}

double Quadrat_ymax(QUADRAT* meinQuadrat)
{
	return MAX4(Punkt_y(meinQuadrat->A),Punkt_y(meinQuadrat->B),Punkt_y(meinQuadrat->C), Punkt_x(meinQuadrat->D));
}
