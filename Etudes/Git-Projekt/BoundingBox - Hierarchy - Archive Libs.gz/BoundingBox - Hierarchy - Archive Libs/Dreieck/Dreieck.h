#ifndef Dreieck_h
#define Dreieck_h

#include "Punkt.h"

/************ Dreieck *************/
struct sDreieck
{	
	/*		     C							*/
	/*		   /   \						*/
	/*		  b	a						*/
	/*		 /	  \						*/
	/*		A -- c  -- B						*/

	PUNKT A,B,C ;
} ;

typedef struct sDreieck DREIECK;

void Dreieck_definiere(PUNKT x, PUNKT y, PUNKT z, DREIECK* meinDreieck);
double Dreieck_Flaeche(DREIECK* meinDreieck);
double Dreieck_Umfang(DREIECK* meinDreieck);
double Dreieck_xmin(DREIECK* meinDreieck);
double Dreieck_xmax(DREIECK* meinDreieck);
double Dreieck_ymin(DREIECK* meinDreieck);
double Dreieck_ymax(DREIECK* meinDreieck);


#endif
