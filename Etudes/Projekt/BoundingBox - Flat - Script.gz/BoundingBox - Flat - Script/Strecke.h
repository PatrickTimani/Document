#ifndef Strecke_h
#define Strecke_h

#include <math.h>
#include "Punkt.h"

struct sStrecke
{
	/*
	  y
	   ^
	   |
	   |
	   |         . a     
	   |      s /
	   |       /  
	   |      /
	   |   b .
	   |
	   ------------------------------>x
	 */

PUNKT a;
PUNKT b;
} ;

typedef struct sStrecke STRECKE;

void Strecke_definiere(PUNKT x, PUNKT y, STRECKE *s);
double Strecke_laenge(STRECKE s);

#endif
