#include <stdio.h>

#include "Rechteck.h"
#include "Kreis.h"
#include "Dreieck.h"
#include "Quadrat.h"
#include "Punkt.h"

#include "minmax.h"


int main()
{
	RECHTECK sR;
	QUADRAT  sQ;
	DREIECK  sD;
	KREIS    sK;

	PUNKT w, x, y, z;

	double xmin, xmax, ymin, ymax;
	double dStrecke;

	/* Rechteck */

	Punkt_definiere(2.0,0.0,&w);
	Punkt_definiere(4.0,0.0,&x);
	Punkt_definiere(4.0,5.0,&y);
	Punkt_definiere(2.0,5.0,&z);
	
	Rechteck_definiere(w,x,y,z,&sR);
	printf("Rechteckflaeche %lf\n", Rechteck_Flaeche(&sR));
	printf("Rechteckumfang %lf\n", Rechteck_Umfang(&sR));
	printf("ymax       %lf\n",       Rechteck_ymax(&sR));
	printf("xmin %lf   %lf xmax  \n",Rechteck_xmin(&sR), Rechteck_xmax(&sR));
	printf("ymin       %lf\n",       Rechteck_ymin(&sR));
	printf("\n");

	/* Quadrat */

	Punkt_definiere(2.0,1.0,&w);
	Punkt_definiere(4.0,2.0,&x);
	Punkt_definiere(3.0,4.0,&y);
	Punkt_definiere(1.0,3.0,&z);


	Quadrat_definiere(w,x,y,z,&sQ);
	printf("Quadratflaeche %lf\n", Quadrat_Flaeche(&sQ));
	printf("Quadratumfang %lf\n", Quadrat_Umfang(&sQ));
	printf("ymax       %lf\n",Quadrat_ymax(&sQ));
	printf("xmin %lf   %lf xmax  \n",Quadrat_xmin(&sQ), Quadrat_xmax(&sQ));
	printf("ymin       %lf\n",Quadrat_ymin(&sQ));
	printf("\n");

	/* Dreieck */

	Punkt_definiere(1.0,1.0,&w);
	Punkt_definiere(4.0,1.0,&x);
	Punkt_definiere(2.0,4.0,&y);

	Dreieck_definiere(w,x,y,&sD);
	printf("Dreieckflaeche %lf\n", Dreieck_Flaeche(&sD));
	printf("Dreieckumfang %lf\n", Dreieck_Umfang(&sD));
	printf("ymax       %lf\n",Dreieck_ymax(&sD));
	printf("xmin %lf   %lf xmax  \n",Dreieck_xmin(&sD), Dreieck_xmax(&sD));
	printf("ymin       %lf\n",Dreieck_ymin(&sD));
	printf("\n");

	/* Kreis */

	Punkt_definiere(2.0,2.0,&w);

	Kreis_definiere(w,3.0,&sK);
	printf("Kreisflaeche %lf\n", Kreis_Flaeche(&sK));
	printf("Kreisumfang %lf\n", Kreis_Umfang(&sK));
	printf("ymax       %lf\n",Kreis_ymax(&sK));
	printf("xmin %lf   %lf xmax  \n",Kreis_xmin(&sK), Kreis_xmax(&sK));
	printf("ymin       %lf\n",Kreis_ymin(&sK));
	printf("\n");
	

	/* Bounding Box*/
	xmin=MIN4(Rechteck_xmin(&sR), Quadrat_xmin(&sQ), Dreieck_xmin(&sD), Kreis_xmin(&sK));
	xmax=MAX4(Rechteck_xmax(&sR), Quadrat_xmax(&sQ), Dreieck_xmax(&sD), Kreis_xmax(&sK));
	ymin=MIN4(Rechteck_ymin(&sR), Quadrat_ymin(&sQ), Dreieck_ymin(&sD), Kreis_ymin(&sK));
	ymax=MAX4(Rechteck_ymax(&sR), Quadrat_ymax(&sQ), Dreieck_ymax(&sD), Kreis_ymax(&sK));

	printf("Bounding Box:\n");
	printf("ymax        %lf\n",ymax);
	printf("xmin %lf    %lf xmax  \n",xmin, xmax);
	printf("ymin        %lf\n\n",ymin);
		
	/* Tonerverbrauch */
	dStrecke=Rechteck_Umfang(&sR)+Quadrat_Umfang(&sQ)+Dreieck_Umfang(&sD)+Kreis_Umfang(&sK);
	printf("Strecke: %lf  Tonerverbrauch %lf g\n\n", 
		dStrecke		/* in cm */, 
		dStrecke * 10	/* g */ * 0.0001 /* wg. Quadratmeter */);

	return 0;
}
