#include "Strecke.h"

#include <math.h>


void Strecke_definiere(PUNKT x, PUNKT y, STRECKE *s)
{
s->a=x;
s->b=y;
}

double Strecke_laenge(STRECKE s)
{
double x1 = Punkt_x(s.a);
double x2 = Punkt_x(s.b);

double y1 = Punkt_y(s.a);
double y2 = Punkt_y(s.b);

return sqrt(fabs(x1-x2)*fabs(x1-x2) + fabs(y1-y2)*fabs(y1-y2));
}

