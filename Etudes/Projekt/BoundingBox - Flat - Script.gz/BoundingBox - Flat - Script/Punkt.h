#ifndef Punkt_h
#define Punkt_h

struct sPunkt
{
	/*
	 *y
	 * ^
	 * |
	 * |
	 * |                 . (x,y)
	 * |
	 * |
	 * |
	 * |
	 * |
	 *  ------------------------------>x
	 */

double x;
double y;
} ;

typedef struct sPunkt PUNKT;

void Punkt_definiere(double x, double y, PUNKT* meinPunkt);
double Punkt_x(PUNKT meinPunkt);
double Punkt_y(PUNKT meinPunkt);

#endif
