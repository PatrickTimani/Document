#include "Dreieck.h"
#include "Strecke.h"
#include <math.h>
#include "minmax.h"


/************ Dreieck *************/
void Dreieck_definiere(PUNKT x, PUNKT y, PUNKT z, DREIECK* meinDreieck)
{	
	/*			C								*/
	/*		   /  \								*/
	/*		  b		a							*/
	/*		 /		  \							*/
	/*		A -- c  -- B						*/

	meinDreieck->A=x;
	meinDreieck->B=y;
	meinDreieck->C=z;
}


double Dreieck_Flaeche(DREIECK* meinDreieck)
{
	/** A = wurzel[s(s-a)(s-b)(s-c)], s = (a+b+c)/2 oder Umfang/2 ***/
	double s;
	STRECKE a, b, c;
	Strecke_definiere(meinDreieck->A, meinDreieck->B,&c);
	Strecke_definiere(meinDreieck->B, meinDreieck->C,&a);
	Strecke_definiere(meinDreieck->C, meinDreieck->A,&b);

	s=Dreieck_Umfang(meinDreieck)/2;
	return sqrt(s*(s-Strecke_laenge(a))*(s-Strecke_laenge(b))*(s-Strecke_laenge(c)));
}

double Dreieck_Umfang(DREIECK* meinDreieck)
{
	STRECKE a, b, c;
	Strecke_definiere(meinDreieck->A, meinDreieck->B,&c);
	Strecke_definiere(meinDreieck->B, meinDreieck->C,&a);
	Strecke_definiere(meinDreieck->C, meinDreieck->A,&b);

	return Strecke_laenge(a)+Strecke_laenge(b)+Strecke_laenge(c);
}

double Dreieck_xmin(DREIECK* meinDreieck)
{//TODO
	return MIN3(Punkt_x(meinDreieck->A),Punkt_x(meinDreieck->B),Punkt_x(meinDreieck->C));
}//END TODO

double Dreieck_xmax(DREIECK* meinDreieck)
{
	return MAX3(Punkt_x(meinDreieck->A),Punkt_x(meinDreieck->B),Punkt_x(meinDreieck->C));
}

double Dreieck_ymin(DREIECK* meinDreieck)
{ 
	return MIN3(Punkt_y(meinDreieck->A),Punkt_y(meinDreieck->B),Punkt_y(meinDreieck->C));

}

double Dreieck_ymax(DREIECK* meinDreieck)
{
	return MAX3(Punkt_y(meinDreieck->A),Punkt_y(meinDreieck->B),Punkt_y(meinDreieck->C));
}



