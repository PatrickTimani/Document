#include "Rechteck.h"
#include "Strecke.h"
#include <math.h>
#include "minmax.h"

/************ Rechteck *************/
void Rechteck_definiere(PUNKT w, PUNKT x, PUNKT y, PUNKT z, RECHTECK* meinRechteck)
{	
	/*		z-----------y		*/
	/*		|  			|		*/
	/*	  	| 			|b		*/
	/*		| 			|		*/
	/*		w-----------x		*/
    /*			  a				*/

	meinRechteck->A=w;
	meinRechteck->B=x;
	meinRechteck->C=y;
	meinRechteck->D=z;
	
}


double Rechteck_Flaeche(RECHTECK* meinRechteck)
{
	STRECKE a, b;
	Strecke_definiere(meinRechteck->A, meinRechteck->B,&a);
	Strecke_definiere(meinRechteck->B, meinRechteck->C,&b);

	return Strecke_laenge(a)*Strecke_laenge(b);
}

double Rechteck_Umfang(RECHTECK* meinRechteck)
{
	STRECKE a, b;
	Strecke_definiere(meinRechteck->A, meinRechteck->B,&a);
	Strecke_definiere(meinRechteck->B, meinRechteck->C,&b);

	return 2* (Strecke_laenge(a)*Strecke_laenge(b));
}

double Rechteck_xmin(RECHTECK* meinRechteck)
{
	return MIN4(Punkt_x(meinRechteck->A),Punkt_x(meinRechteck->B),Punkt_x(meinRechteck->C), Punkt_x(meinRechteck->D));
}

double Rechteck_xmax(RECHTECK* meinRechteck)
{
	return MAX4(Punkt_x(meinRechteck->A),Punkt_x(meinRechteck->B),Punkt_x(meinRechteck->C), Punkt_x(meinRechteck->D));
}

double Rechteck_ymin(RECHTECK* meinRechteck)
{ 
	return MIN4(Punkt_y(meinRechteck->A),Punkt_y(meinRechteck->B),Punkt_y(meinRechteck->C), Punkt_x(meinRechteck->D));

}

double Rechteck_ymax(RECHTECK* meinRechteck)
{
	return MAX4(Punkt_y(meinRechteck->A),Punkt_y(meinRechteck->B),Punkt_y(meinRechteck->C), Punkt_x(meinRechteck->D));
}
