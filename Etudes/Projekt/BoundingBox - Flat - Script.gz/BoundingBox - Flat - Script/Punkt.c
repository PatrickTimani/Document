#include "Punkt.h"

void Punkt_definiere(double x, double y, PUNKT* meinPunkt)
{
meinPunkt->x=x;
meinPunkt->y=y;
}

double Punkt_x(PUNKT meinPunkt) {return meinPunkt.x;}
double Punkt_y(PUNKT meinPunkt) {return meinPunkt.y;}
