#include "Kreis.h"


/************ Kreis *************/
void Kreis_definiere(PUNKT x, double dRadius, /*@out@*/ KREIS* meinKreis)
{
	meinKreis->m=x;
	meinKreis->radius=dRadius;
}

double Kreis_Flaeche(KREIS* meinKreis)
{
	return PI*meinKreis->radius*meinKreis->radius;
}

double Kreis_Umfang(KREIS* meinKreis)
{
	return 2*PI*meinKreis->radius;
}

double Kreis_Bogen(double alpha, KREIS* meinKreis)
{
	return Kreis_Umfang(meinKreis) * alpha / 2 * PI;
}
double Kreis_Sektor(double alpha, KREIS* meinKreis)
{
	return Kreis_Flaeche(meinKreis) * alpha / 2 * PI;
}

double Kreis_xmin(KREIS* meinKreis)
{
	return Punkt_x(meinKreis->m) - meinKreis->radius;
}

double Kreis_xmax(KREIS* meinKreis)
{
	return Punkt_x(meinKreis->m) + meinKreis->radius;
}

double Kreis_ymin(KREIS* meinKreis)
{
	return Punkt_y(meinKreis->m) - meinKreis->radius;
}

double Kreis_ymax(KREIS* meinKreis)
{
	return Punkt_y(meinKreis->m) + meinKreis->radius;
}

