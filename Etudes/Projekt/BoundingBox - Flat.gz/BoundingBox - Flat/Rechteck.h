#ifndef Rechteck_h
#define Rechteck_h

#include "Punkt.h"

/************ Rechteck *************/
struct sRechteck
{
	/*		D-----------C		*/
	/*		|  	    |		*/
	/*	  	| 	    |b		*/
	/*		| 	    |		*/
	/*		A-----------B		*/
	/*		      a			*/

	PUNKT A,B,C,D;

} ;

typedef struct sRechteck RECHTECK;

void Rechteck_definiere(PUNKT w, PUNKT x, PUNKT y, PUNKT z, /*@out@*/ RECHTECK* meinRechteck);
double Rechteck_Flaeche(RECHTECK* meinRechteck);
double Rechteck_Umfang(RECHTECK* meinRechteck);
double Rechteck_xmin(RECHTECK* meinRechteck);
double Rechteck_xmax(RECHTECK* meinRechteck);
double Rechteck_ymin(RECHTECK* meinRechteck);
double Rechteck_ymax(RECHTECK* meinRechteck);

#endif
